package com.cafe.model;

import java.util.Date;

public class Order {
    private int id;
    private int userId;
    private double totalamount;
    private Date orderDate;

    // Constructors
    public Order() {}

    public Order(int id, int userId, double totalamount, Date orderDate) {
        this.id = id;
        this.userId = userId;
        this.totalamount = totalamount;
        this.orderDate = orderDate;
    }

    // Getters and Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }

    public double getTotalamount() { return totalamount; }
    public void setTotalamonut(double totalPrice) { this.totalamount = totalamount; }

    public Date getOrderDate() { return orderDate; }
    public void setOrderDate(Date orderDate) { this.orderDate = orderDate; }

    public void setTotalamount(double aDouble) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
