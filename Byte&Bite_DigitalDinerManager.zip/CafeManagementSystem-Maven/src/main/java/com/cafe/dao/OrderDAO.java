package com.cafe.dao;

import java.sql.*;
import java.util.*;
import com.cafe.model.Order;
import com.cafe.util.DBConnection;

public class OrderDAO {

    // Get all orders by user ID
    public static List<Order> getOrdersByUserId(int user_Id) {
        List<Order> orders = new ArrayList<>();
        String query = "SELECT * FROM orders WHERE user_id = ? ORDER BY order_date DESC";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setInt(1, user_Id);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Order order = new Order();
                order.setId(rs.getInt("id"));
                order.setUserId(rs.getInt("user_id"));
                order.setTotalamount(rs.getDouble("total_amount"));
                order.setOrderDate(rs.getTimestamp("order_date"));
                orders.add(order);
            }

        } catch (SQLException e) {
            System.err.println("Error fetching orders by user ID:");
            e.printStackTrace();
        }

        return orders;
    }

    // Place a new order
    public static boolean placeOrder(int userId, double totalamount) {
        String query = "INSERT INTO orders (user_id, total_amount, order_date) VALUES (?, ?, NOW())";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setInt(1, userId);
            stmt.setDouble(2, totalamount);

            int rowsInserted = stmt.executeUpdate();
            return rowsInserted > 0;

        } catch (SQLException e) {
            System.err.println("Error placing order:");
            e.printStackTrace();
        }

        return false;
    }

    // (Optional) Get last order ID placed by user
    public static int getLastOrderIdByUser(int userId) {
        String query = "SELECT id FROM orders WHERE user_id = ? ORDER BY order_date DESC LIMIT 1";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setInt(1, userId);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return rs.getInt("id");
            }

        } catch (SQLException e) {
            System.err.println("Error fetching last order ID:");
            e.printStackTrace();
        }

        return -1;
    }
}
